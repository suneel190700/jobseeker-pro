(function(){
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg.action==='quick_fill'){doFill().then(sendResponse);return true;}
  if(msg.action==='optimize_and_fill'){doOptimize(msg.coverLetter).then(sendResponse);return true;}
  if(msg.action==='save_job'){doSave().then(sendResponse);return true;}
  if(msg.action==='score'){doScore().then(sendResponse);return true;}
});

function label(el){if(el.id){const l=document.querySelector(`label[for="${el.id}"]`);if(l)return l.textContent.trim();}const p=el.closest('label');if(p)return p.textContent.trim();return el.getAttribute('aria-label')||el.placeholder||el.name||el.id||'';}
function setV(el,v){if(!v||!el)return false;const s=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value')?.set||Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value')?.set;if(s)s.call(el,v);else el.value=v;['input','change','blur'].forEach(e=>el.dispatchEvent(new Event(e,{bubbles:true})));return true;}

function detectJD(){const s=['#job-details','.jobs-description__content','.jobsearch-jobDescriptionText','.jobDescriptionContent','.posting-page','.job-description','article','.job_description'];for(const x of s){const el=document.querySelector(x);if(el?.textContent?.trim().length>100)return el.textContent.trim();}let b='',bl=0;document.querySelectorAll('div,section,article').forEach(d=>{const t=d.textContent?.trim()||'';if(t.length>200&&t.length<15000&&t.length>bl){b=t;bl=t.length;}});return b;}
function detectTitle(){for(const s of['.job-details-jobs-unified-top-card__job-title','h1.t-24','.jobsearch-JobInfoHeader-title','h1']){const el=document.querySelector(s);if(el?.textContent?.trim())return el.textContent.trim();}return document.title.split(' - ')[0].split(' | ')[0].trim();}
function detectCompany(){for(const s of['.job-details-jobs-unified-top-card__company-name','.jobsearch-InlineCompanyRating-companyHeader','[data-testid="inlineHeader-companyName"]','.company-name']){const el=document.querySelector(s);if(el?.textContent?.trim())return el.textContent.trim();}return '';}

async function getProfile(){return new Promise((res,rej)=>{chrome.runtime.sendMessage({type:'GET_PROFILE'},r=>r?.error?rej(new Error(r.error)):res(r));});}

function fillForm(p){
  const map={'first name':p.first_name,'firstname':p.first_name,'fname':p.first_name,'last name':p.last_name,'lastname':p.last_name,'lname':p.last_name,'full name':p.name,'name':p.name,'email':p.email,'e-mail':p.email,'phone':p.phone,'mobile':p.phone,'tel':p.phone,'city':p.city,'state':p.state,'location':p.location,'address':p.location,'linkedin':p.linkedin,'github':p.github,'website':p.website||p.linkedin,'portfolio':p.website,'salary':p.salary_expectation,'compensation':p.salary_expectation,'experience':p.years_experience,'years':p.years_experience,'company':p.current_company,'employer':p.current_company,'current company':p.current_company,'title':p.current_title,'current title':p.current_title,'job title':p.current_title,'position':p.current_title,'university':p.university,'school':p.university,'college':p.university,'degree':p.degree,'gpa':p.gpa,'graduation':p.graduation_year,'authorization':p.work_authorization,'visa':p.work_authorization,'sponsorship':p.work_authorization};
  let n=0;document.querySelectorAll('input,textarea,select').forEach(el=>{if(['hidden','submit','button','file','checkbox','radio'].includes(el.type))return;if(el.value?.length>0)return;const k=(label(el)+' '+(el.name||'')+' '+(el.id||'')+' '+(el.placeholder||'')).toLowerCase();for(const[pat,val]of Object.entries(map)){if(val&&k.includes(pat)){if(setV(el,val)){el.style.boxShadow='0 0 0 2px rgba(60,89,253,0.5)';n++;}break;}}});return n;
}

function uploadResumeFile(blob, filename) {
  const inputs = document.querySelectorAll('input[type="file"]');
  if (!inputs.length) return false;
  const file = new File([blob], filename, { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  const dt = new DataTransfer(); dt.items.add(file);
  for (const inp of inputs) {
    const k = (label(inp) + ' ' + inp.name + ' ' + inp.id).toLowerCase();
    if (k.includes('resume') || k.includes('cv') || k.includes('upload') || !k.trim()) {
      inp.files = dt.files; inp.dispatchEvent(new Event('change', { bubbles: true })); return true;
    }
  }
  inputs[0].files = dt.files; inputs[0].dispatchEvent(new Event('change', { bubbles: true })); return true;
}

async function doFill(){try{const p=await getProfile();return{success:true,message:`Filled ${fillForm(p)} fields`};}catch(e){return{error:e.message};}}

async function doScore(){try{const jd=detectJD();if(!jd||jd.length<50)return{error:'No JD detected'};const r=await new Promise((res,rej)=>{chrome.runtime.sendMessage({type:'SCORE',jd},r=>r?.error?rej(new Error(r.error)):res(r));});return{success:true,score:r};}catch(e){return{error:e.message};}}

async function doOptimize(wantCL){try{const p=await getProfile();const jd=detectJD();const title=detectTitle();const company=detectCompany();if(!jd||jd.length<50)return{error:'No JD detected on this page'};
const r=await new Promise((res,rej)=>{chrome.runtime.sendMessage({type:'OPTIMIZE',jd,title,company,coverLetter:wantCL},r=>r?.error?rej(new Error(r.error)):res(r));});
const n=fillForm(p);
if(wantCL&&r.coverLetter){document.querySelectorAll('textarea').forEach(t=>{const k=(label(t)+' '+t.name+' '+t.id+' '+t.placeholder).toLowerCase();if(k.includes('cover')||k.includes('letter')||k.includes('message')||k.includes('why'))setV(t,r.coverLetter);});}
chrome.runtime.sendMessage({type:'SAVE_JOB',job:{title,company,source_url:window.location.href,source:'Extension'}});
const scoreText = r.score ? ` | ATS: ${r.score.overall_score}%` : '';
return{success:true,message:`Optimized + ${n} fields filled${wantCL?' + cover letter':''}${scoreText}`,score:r.score,resume:r.resume};}catch(e){return{error:e.message};}}

async function doSave(){try{const t=detectTitle();const c=detectCompany();await new Promise((res,rej)=>{chrome.runtime.sendMessage({type:'SAVE_JOB',job:{title:t,company:c,source_url:window.location.href,source:'Extension'}},r=>r?.error?rej(new Error(r.error)):res(r));});return{success:true,message:`Saved "${t}"`};}catch(e){return{error:e.message};}}
})();
