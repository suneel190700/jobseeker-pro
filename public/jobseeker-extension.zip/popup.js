const API='https://jobseeker-pro.vercel.app';
let lastResume = null;

document.addEventListener('DOMContentLoaded',async()=>{
  const{auth_token}=await chrome.storage.local.get(['auth_token']);
  if(auth_token){try{const p=await msg('GET_PROFILE');document.getElementById('un').textContent=p.name||'User';document.getElementById('ue').textContent=p.email||'';show('conn');}catch{show('login');}}
  else show('login');
});

function show(id){document.getElementById('conn').style.display=id==='conn'?'block':'none';document.getElementById('login').style.display=id==='login'?'block':'none';}
function res(m,ok){const el=document.getElementById('res');el.style.display='block';el.style.background=ok?'rgba(0,218,243,0.1)':'rgba(255,180,171,0.1)';el.style.color=ok?'#00daf3':'#ffb4ab';el.style.border=`1px solid ${ok?'rgba(0,218,243,0.2)':'rgba(255,180,171,0.2)'}`;el.textContent=m;}
function msg(type,data={}){return new Promise((res,rej)=>{chrome.runtime.sendMessage({type,...data},r=>r?.error?rej(new Error(r.error)):res(r));});}

function showScores(containerId, impressionId, scoreData) {
  if (!scoreData) return;
  const c = document.getElementById(containerId);
  const imp = document.getElementById(impressionId);
  c.innerHTML = '';
  if (scoreData.overall_score) {
    c.innerHTML += `<div class="sc-card"><div class="sc-num">${scoreData.overall_score}%</div><div class="sc-lbl">Overall</div></div>`;
  }
  if (scoreData.ats_scores) {
    for (const [p, s] of Object.entries(scoreData.ats_scores)) {
      c.innerHTML += `<div class="sc-card"><div class="sc-num" style="font-size:14px">${s}%</div><div class="sc-lbl">${p}</div></div>`;
    }
  }
  c.parentElement.style.display = 'block';
  if (scoreData.recruiter_impression) imp.textContent = `"${scoreData.recruiter_impression}"`;
}

async function inject(action, extra={}) {
  const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
  if (!tab?.id) { res('No active tab',false); return null; }
  try { await chrome.scripting.executeScript({target:{tabId:tab.id},files:['content.js']}); await chrome.scripting.insertCSS({target:{tabId:tab.id},files:['content.css']}); } catch {}
  return new Promise(resolve => {
    chrome.tabs.sendMessage(tab.id, {action,...extra}, r => {
      if (chrome.runtime.lastError) { res('Refresh page and retry',false); resolve(null); return; }
      resolve(r);
    });
  });
}

// Score button
document.getElementById('btn-score')?.addEventListener('click', async () => {
  res('Scoring...',true);
  const r = await inject('score');
  if (r?.success && r.score) { showScores('score-cards','score-impression',r.score); res(`ATS Score: ${r.score.overall_score}%`,true); }
  else res(r?.error||'Failed',false);
});

// Optimize button
document.getElementById('btn-opt')?.addEventListener('click', async () => {
  const cl = document.getElementById('cl-tog').checked;
  res('Optimizing (20-30s)...',true);
  const r = await inject('optimize_and_fill',{coverLetter:cl});
  if (r?.success) {
    res(r.message,true);
    if (r.score) showScores('opt-scores','opt-impression',r.score);
    if (r.resume) { lastResume = r.resume; document.getElementById('opt-result').style.display='block'; }
  } else res(r?.error||'Failed',false);
});

// Download buttons
document.getElementById('dl-docx')?.addEventListener('click', () => {
  if (!lastResume) return;
  res('Downloading DOCX...',true);
  msg('DOWNLOAD',{resume:lastResume,format:'docx'}).then(()=>res('Downloaded!',true)).catch(e=>res(e.message,false));
});
document.getElementById('dl-pdf')?.addEventListener('click', () => {
  if (!lastResume) return;
  res('Downloading PDF...',true);
  msg('DOWNLOAD',{resume:lastResume,format:'pdf'}).then(()=>res('Downloaded!',true)).catch(e=>res(e.message,false));
});

// Other buttons
document.getElementById('btn-fill')?.addEventListener('click', async () => { res('Filling...',true); const r=await inject('quick_fill'); if(r?.success)res(r.message,true);else res(r?.error||'Failed',false); });
document.getElementById('btn-save')?.addEventListener('click', async () => { res('Saving...',true); const r=await inject('save_job'); if(r?.success)res(r.message,true);else res(r?.error||'Failed',false); });

// Login
document.getElementById('login-btn')?.addEventListener('click',async()=>{
  const e=document.getElementById('email').value,p=document.getElementById('pw').value;if(!e||!p)return;
  const b=document.getElementById('login-btn');b.textContent='Connecting...';b.disabled=true;
  try{const r=await fetch(`${API}/api/auth/extension-login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email:e,password:p})});const d=await r.json();if(d.token){await chrome.storage.local.set({auth_token:d.token});location.reload();}else res(d.error||'Failed',false);}
  catch{res('Connection failed',false);}finally{b.textContent='Connect';b.disabled=false;}
});
document.getElementById('logout')?.addEventListener('click',async()=>{await chrome.storage.local.remove(['auth_token','profile_cache','profile_ts']);location.reload();});
document.getElementById('open-app')?.addEventListener('click',()=>{chrome.tabs.create({url:`${API}/dashboard`});});
