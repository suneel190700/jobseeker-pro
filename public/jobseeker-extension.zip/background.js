const API='https://jobseeker-pro.vercel.app';

chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  const handlers = {
    'GET_PROFILE': () => getProfile(),
    'OPTIMIZE': () => optimize(msg.jd, msg.title, msg.company, msg.coverLetter),
    'SCORE': () => scoreResume(msg.jd),
    'DOWNLOAD': () => downloadResume(msg.resume, msg.format),
    'SAVE_JOB': () => saveJob(msg.job),
  };
  if (handlers[msg.type]) { handlers[msg.type]().then(sendResponse).catch(e => sendResponse({ error: e.message })); return true; }
});

async function getToken() {
  const { auth_token } = await chrome.storage.local.get(['auth_token']);
  if (!auth_token) throw new Error('Not logged in');
  return auth_token;
}

async function getProfile() {
  const t = await getToken();
  const c = await chrome.storage.local.get(['profile_cache', 'profile_ts']);
  if (c.profile_cache && c.profile_ts && Date.now() - c.profile_ts < 3600000) return c.profile_cache;
  const r = await fetch(`${API}/api/profile`, { headers: { Authorization: `Bearer ${t}` } });
  if (!r.ok) throw new Error('Profile fetch failed');
  const p = await r.json();
  await chrome.storage.local.set({ profile_cache: p, profile_ts: Date.now() });
  return p;
}

async function scoreResume(jd) {
  const t = await getToken();
  const p = await getProfile();
  if (!p.resume_text) throw new Error('No resume uploaded in profile');
  const r = await fetch(`${API}/api/resume/score-ai`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ resumeText: p.resume_text, jobDescription: jd })
  });
  if (!r.ok) throw new Error('Scoring failed');
  return r.json();
}

async function optimize(jd, title, company, wantCoverLetter) {
  const t = await getToken();
  const p = await getProfile();
  if (!p.resume_text) throw new Error('No resume uploaded in profile');
  const r = await fetch(`${API}/api/resume/generate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` },
    body: JSON.stringify({ resumeText: p.resume_text, jobDescription: jd, jobTitle: title, company, userName: p.name })
  });
  if (!r.ok) throw new Error('Optimization failed');
  const data = await r.json();

  // Score the optimized resume
  try {
    const scoreR = await fetch(`${API}/api/resume/score-ai`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ resumeText: JSON.stringify(data.resume), jobDescription: jd })
    });
    if (scoreR.ok) data.score = await scoreR.json();
  } catch {}

  // Generate cover letter if requested
  if (wantCoverLetter) {
    try {
      const cl = await fetch(`${API}/api/cover-letter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resumeText: JSON.stringify(data.resume), jobDescription: jd, jobTitle: title, company, tone: 'professional' })
      });
      if (cl.ok) { const cld = await cl.json(); data.coverLetter = cld.coverLetter || cld.text || ''; }
    } catch {}
  }

  return data;
}

async function downloadResume(resume, format) {
  const r = await fetch(`${API}/api/resume/download`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ resume, format: format || 'docx', filename: resume._filename || 'resume' })
  });
  if (!r.ok) throw new Error('Download failed');
  const blob = await r.blob();
  const reader = new FileReader();
  return new Promise((resolve, reject) => {
    reader.onloadend = async () => {
      try {
        await chrome.downloads.download({ url: reader.result, filename: `${resume._filename || 'optimized_resume'}.${format || 'docx'}` });
        resolve({ success: true });
      } catch (e) { reject(e); }
    };
    reader.onerror = () => reject(new Error('Read failed'));
    reader.readAsDataURL(blob);
  });
}

async function saveJob(job) {
  const t = await getToken();
  const r = await fetch(`${API}/api/tracker`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${t}` },
    body: JSON.stringify(job)
  });
  if (!r.ok) throw new Error('Save failed');
  return { success: true };
}
